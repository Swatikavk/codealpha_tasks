# Flashcard Quiz App

Features:
- Question on the front and answer on the back
- Show Answer button
- Next / Previous navigation
- Add, edit, and delete flashcards
- Clean and simple user interface
- Local storage support

Run:
Open `index.html` in a browser.
